#ifndef _CUBO_H
#define _CUBO_H

#include "objeto3D.h"
using namespace std;

class Cubo : public Objeto3D {

  public:
    Cubo();

};

#endif
