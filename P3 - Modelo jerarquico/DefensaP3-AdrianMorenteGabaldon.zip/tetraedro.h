#ifndef _TETRAEDRO_H
#define _TETRAEDRO_H

#include "objeto3D.h"
using namespace std;

class Tetraedro : public Objeto3D {

  public:
    Tetraedro();

};
#endif
